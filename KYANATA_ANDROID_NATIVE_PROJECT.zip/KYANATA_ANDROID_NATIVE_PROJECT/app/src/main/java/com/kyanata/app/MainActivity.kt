package com.kyanata.app

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.CookieManager
import java.net.CookiePolicy
import java.io.OutputStreamWriter
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val baseUrl = "http://paizeepanel.duckdns.top:4914/"
    private val cookies = CookieManager(null, CookiePolicy.ACCEPT_ALL)
    private lateinit var root: LinearLayout
    private var username = ""
    private var provider = "cici"
    private val bg = Color.rgb(12, 12, 16)
    private val panel = Color.rgb(28, 28, 35)
    private val red = Color.rgb(235, 55, 65)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        java.net.CookieHandler.setDefault(cookies)
        showLogin()
        createNotificationChannel()
    }

    private fun setup(title: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(20), dp(24), dp(20), dp(20)) }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        val heading = TextView(this).apply { text = title; textSize = 27f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(18)) }
        root.addView(heading, match())
    }

    private fun showLogin() {
        setup("KYANATA")
        text("NATIVE ANDROID", 13f, red, true)
        val user = edit("Username", false)
        val pass = edit("Password", true)
        button("MASUK") {
            val u = user.text.toString().trim(); val p = pass.text.toString()
            if (u.isBlank() || p.isBlank()) { toast("Isi username dan password dulu"); return@button }
            request("POST", "api/login", JSONObject().put("username", u).put("password", p)) { code, body ->
                runOnUiThread {
                    if (code in 200..299) { username = u; showDashboard() }
                    else toast(parseError(body, "Login gagal ($code)"))
                }
            }
        }
        text("Server: $baseUrl", 11f, Color.LTGRAY, false)
        button("CEK KONEKSI SERVER") { request("GET", "api/status", null) { c,b -> runOnUiThread { toast(if(c in 200..299) "Server merespons" else "Server gagal: $c") } } }
    }

    private fun showDashboard() {
        setup("KYANATA")
        text("Halo, $username", 16f, Color.LTGRAY, true)
        text("Pilih AI", 14f, white, true)
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val cici = RadioButton(this).apply { text = "Cici"; setTextColor(white); isChecked = provider == "cici" }
        val gpt = RadioButton(this).apply { text = "GPT-5 mini"; setTextColor(white); isChecked = provider == "gpt5mini" }
        group.addView(cici); group.addView(gpt); root.addView(group)
        group.setOnCheckedChangeListener { _, id -> provider = if (id == gpt.id) "gpt5mini" else "cici" }
        val prompt = edit("Tulis pertanyaan untuk AI...", false)
        button("KIRIM KE AI") {
            val message = prompt.text.toString().trim(); if(message.isBlank()){toast("Tulis pertanyaan dulu");return@button}
            request("POST", "api/ai-chat", JSONObject().put("message", message).put("provider", provider)) { c,b -> runOnUiThread {
                if(c in 200..299) { val answer = try { JSONObject(b).optString("answer", b) } catch(_:Exception){b}; showAnswer(answer) }
                else toast(parseError(b, "AI gagal ($c)"))
            } }
        }
        val form = edit("Link Google Forms (https://docs.google.com/forms/...)", false)
        button("PROSES LINK FORM") {
            val link=form.text.toString().trim(); if(link.isBlank()){toast("Masukkan link Google Forms");return@button}
            request("POST", "api/answer-link", JSONObject().put("url", link).put("provider", provider)) { c,b -> runOnUiThread {
                if(c in 200..299) { val answer=try{JSONObject(b).optString("answer",b)}catch(_:Exception){b}; showAnswer(answer) }
                else toast(parseError(b,"Gagal memproses form ($c)"))
            } }
        }
        button("RIWAYAT") { showHistory() }
        button("NOTIFIKASI TES") { showNotification("KYANATA", "Notifikasi aplikasi berhasil dipanggil.") }
        button("KELUAR") { request("POST", "api/logout", JSONObject()) { _,_ -> runOnUiThread { cookies.cookieStore.removeAll(); showLogin() } } }
    }

    private fun showAnswer(answer: String) {
        setup("HASIL AI")
        val box = TextView(this).apply { text = answer; textSize = 15f; setTextColor(white); setPadding(dp(14),dp(14),dp(14),dp(14)); setBackgroundColor(panel) }
        root.addView(box, match())
        button("SALIN") { val cm=getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager; cm.setPrimaryClip(android.content.ClipData.newPlainText("Jawaban KYANATA", answer)); toast("Jawaban disalin") }
        button("PASTE ULANG") { val cm=getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager; cm.setPrimaryClip(android.content.ClipData.newPlainText("Jawaban KYANATA", answer)); toast("Jawaban disalin lagi") }
        button("JAWABAN BERIKUTNYA") { showDashboard() }
        button("NOTIFIKASI HASIL") { showNotification("Jawaban KYANATA selesai", answer.take(180)) }
        button("KEMBALI") { showDashboard() }
    }

    private fun showHistory() {
        request("GET", "api/history", null) { c,b -> runOnUiThread {
            if(c !in 200..299) { toast(parseError(b,"Riwayat gagal dimuat ($c)")); return@runOnUiThread }
            setup("RIWAYAT KYANATA")
            try {
                val arr=JSONObject(b).optJSONArray("history") ?: JSONArray()
                if(arr.length()==0) text("Belum ada riwayat.",15f,Color.LTGRAY,false)
                for(i in 0 until arr.length()) { val row=arr.optJSONObject(i) ?: continue; text("${row.optString("at")}\n${row.optString("url", row.optString("answer"))}\nAI: ${row.optString("provider")}",13f,white,false) }
            } catch(e:Exception) { text(b,12f,white,false) }
            button("KEMBALI") { showDashboard() }
        } }
    }

    private fun request(method: String, path: String, payload: JSONObject?, done: (Int,String)->Unit) {
        thread {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(baseUrl.trimEnd('/') + "/" + path.trimStart('/')).openConnection() as HttpURLConnection).apply {
                    requestMethod=method; connectTimeout=12000; readTimeout=35000; setRequestProperty("Accept","application/json")
                    if(payload!=null) { doOutput=true; setRequestProperty("Content-Type","application/json; charset=utf-8"); OutputStreamWriter(outputStream,"UTF-8").use { it.write(payload.toString()) } }
                }
                val code=conn.responseCode
                val stream=if(code>=400) conn.errorStream else conn.inputStream
                val body=stream?.bufferedReader()?.use { it.readText() } ?: ""
                done(code,body)
            } catch(e:Exception) { done(-1, e.message ?: "Koneksi gagal") } finally { conn?.disconnect() }
        }
    }

    private fun showNotification(title:String, body:String) {
        val manager=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder=if(Build.VERSION.SDK_INT>=26) android.app.Notification.Builder(this,"kyanata_results") else android.app.Notification.Builder(this)
        builder.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setStyle(android.app.Notification.BigTextStyle().bigText(body)).setAutoCancel(true)
        manager.notify((System.currentTimeMillis()%100000).toInt(), builder.build())
        toast("Notifikasi dikirim")
    }
    private fun createNotificationChannel() { if(Build.VERSION.SDK_INT>=26) { val m=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager; m.createNotificationChannel(NotificationChannel("kyanata_results","KYANATA results",NotificationManager.IMPORTANCE_DEFAULT)) } }
    private fun edit(hint:String, password:Boolean): EditText { val e=EditText(this).apply { this.hint=hint; setHintTextColor(Color.GRAY); setTextColor(white); setPadding(dp(14),dp(10),dp(14),dp(10)); setBackgroundColor(panel); if(password) inputType=129 }; val p=LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(7),0,dp(7)); root.addView(e,p); return e }
    private fun button(label:String, action:()->Unit) { val b=Button(this).apply { text=label; setTextColor(white); setBackgroundColor(red); isAllCaps=false; setOnClickListener { action() } }; val p=LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(6),0,dp(6)); root.addView(b,p) }
    private fun text(value:String,size:Float,color:Int,bold:Boolean) { val t=TextView(this).apply { text=value; textSize=size; setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD; setPadding(0,dp(7),0,dp(7)) }; root.addView(t,match()) }
    private fun match()=LinearLayout.LayoutParams(-1,-2)
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun parseError(body:String, fallback:String):String=try{JSONObject(body).optString("error",fallback)}catch(_:Exception){if(body.startsWith("http")||body.contains("failed",true)) body else fallback}
}
