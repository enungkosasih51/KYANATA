# KYANATA Android Native — panduan build HP

Ini adalah proyek Android native Kotlin, bukan APK jadi dan bukan WebView.

## Build lewat AndroidIDE
1. Ekstrak ZIP ini di HP.
2. Buka folder `KYANATA_ANDROID_NATIVE_PROJECT` dari AndroidIDE sebagai proyek Gradle.
3. Pastikan JDK/Gradle/Android SDK yang cocok tersedia.
4. Sinkronkan Gradle, lalu Build APK.
5. File APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Server
API_BASE URL di `MainActivity.kt` saat ini adalah `http://paizeepanel.duckdns.top:4914/`. Manifest mengizinkan HTTP sesuai permintaan.

## Fitur di scaffold
- Login lewat endpoint `/api/login`
- Pilih Cici atau GPT-5 mini
- Kirim pertanyaan ke `/api/ai-chat`
- Kirim URL Google Forms ke `/api/answer-link`
- Riwayat lewat `/api/history`
- Notifikasi lokal dan tombol SALIN / PASTE ULANG / JAWABAN BERIKUTNYA

## Batasan yang diketahui
- Backend yang disertakan di ZIP asli belum tentu sama dengan server yang sedang online. Endpoint harus cocok.
- Backend memakai Express session; app memakai CookieManager agar cookie sesi disimpan untuk request berikutnya.
- Endpoint Google Forms yang ada belum benar-benar mengekstrak pertanyaan form; backend sendiri memberi tahu AI URL dan tidak mengklaim telah membaca form.
- Notifikasi saat AI selesai dibuat lokal ketika respons diterima; push saat aplikasi benar-benar tertutup perlu FCM/push backend tambahan.
- Saya tidak menyertakan kredensial `.env` dari ZIP asli.
